package modes;

import units.unit;

public class topDown extends mode {

	// Fields
	public static String name = "topDown";
	
	// Set the mode.
	public static void setMode() {
		mode.setCurrentMode(name);
		unit.setGravity(false);
	}
	
}