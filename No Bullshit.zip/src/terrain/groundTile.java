package terrain;

// Something to differentiate doodads from simple tiles.
public class groundTile extends chunk {

	// Constructor
	public groundTile(chunkType c, int newX, int newY) {
		super(c, newX, newY);
	}
	
}